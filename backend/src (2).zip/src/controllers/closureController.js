import SlaughterClosure from '../models/SlaughterClosure.js';
import SlaughterSchedule from '../models/SlaughterSchedule.js';
import SlaughterLot from '../models/SlaughterLot.js';
import { generateClosurePDF } from '../utils/closurePdfGenerator.js';



// @desc    Buscar fechamento por data
// @route   GET /api/slaughter/closure/:date
// @access  Private (protect + checkModule)
export const getClosureByDate = async (req, res, next) => {
    try {
        const { date } = req.params;
        const [year, month, day] = date.split('-').map(Number);
        const normalizedDate = new Date(Date.UTC(year, month - 1, day));


        const closure = await SlaughterClosure.findOne({ date: normalizedDate })
            .populate('scheduleId', 'slaughterDate status totalCattle')
            .populate('closedBy', 'name')
            .populate('reopenLog.by', 'name');


        if (!closure) {
            return res.json({ success: true, data: null });
        }

        res.json({ success: true, data: closure });
    } catch (error) {
        next(error);
    }
};

// @desc    Criar fechamento a partir da escala de abate
// @route   POST /api/slaughter/closure/:date/from-pre
export const createClosureFromPre = async (req, res, next) => {

    try {
        const { date } = req.params;
        const [year, month, day] = date.split('-').map(Number);
        const normalizedDate = new Date(Date.UTC(year, month - 1, day));


        // Verificar se já existe fechamento para esta data
        const existing = await SlaughterClosure.findOne({ date: normalizedDate });
        if (existing) {
            return res.status(400).json({ success: false, message: 'Já existe fechamento para esta data' });
        }

        // Buscar escala de abate fechada
        const schedule = await SlaughterSchedule.findOne({ slaughterDate: normalizedDate });

        if (!schedule) {
            return res.status(404).json({ success: false, message: 'Escala de abate não encontrada para esta data' });
        }

        if (schedule.status !== 'CLOSED') {
            return res.status(400).json({ success: false, message: 'A escala de abate precisa estar FECHADA para iniciar o fechamento SIF' });
        }

        // Buscar lotes da escala
        const lots = await SlaughterLot.find({ schedule: schedule._id }).populate('rancher').sort('order');


        // Mapear lotes para linhas do fechamento
        const lines = lots.map((lot, index) => ({
            sequence: index + 1,
            preLotRefId: lot._id.toString(), // usando ID do lote como ref
            producerName: lot.rancherName,
            municipio: (lot.rancher?.address?.city || '').trim(),
            uf: (lot.rancher?.address?.state || '').trim().substring(0, 2).toUpperCase(),
            brokerCode: lot.brokerNumber,


            brokerName: lot.brokerNumber, // ou outro campo se houver
            boi: lot.boi,
            vaca: lot.vaca,
            novilha: lot.novilha,
            bubalino: lot.bubalino,
            touro: lot.touro,
            curral: '',
            cor: '',
            nf: '',
            observations: ''
        }));

        const closure = await SlaughterClosure.create({
            date: normalizedDate,
            scheduleId: schedule._id,
            status: 'DRAFT',
            header: {
                slaughterDate: normalizedDate,
                sifNumber: 'SIF XXXX' // configurável
            },
            lines,
            createdBy: req.user.id
        });


        res.status(201).json({ success: true, data: closure });
    } catch (error) {
        next(error);
    }
};

// @desc    Atualizar fechamento
// @route   PUT /api/slaughter/closure/:id
export const updateClosure = async (req, res, next) => {
    try {
        const closure = await SlaughterClosure.findById(req.params.id);
        if (!closure) return res.status(404).json({ success: false, message: 'Fechamento não encontrado' });
        if (closure.status === 'CLOSED') return res.status(400).json({ success: false, message: 'Fechamento já está fechado' });

        const allowedFields = ['header', 'lines', 'notes'];
        const updateData = {};
        allowedFields.forEach(f => { if (req.body[f] !== undefined) updateData[f] = req.body[f]; });

        const updated = await SlaughterClosure.findByIdAndUpdate(req.params.id, updateData, { new: true, runValidators: true });
        res.json({ success: true, data: updated });
    } catch (error) {
        next(error);
    }
};

// @desc    Reordenar linhas
// @route   POST /api/slaughter/closure/:id/reorder
export const reorderLines = async (req, res, next) => {
    try {
        const { order } = req.body; // Array de { preLotRefId, sequence }
        const closure = await SlaughterClosure.findById(req.params.id);

        if (!closure) return res.status(404).json({ success: false, message: 'Fechamento não encontrado' });
        if (closure.status === 'CLOSED') return res.status(400).json({ success: false, message: 'Fechamento já está fechado' });

        order.forEach(item => {
            const line = closure.lines.find(l => l.preLotRefId === item.preLotRefId);
            if (line) line.sequence = item.sequence;
        });

        // Garantir ordenação correta no array
        closure.lines.sort((a, b) => a.sequence - b.sequence);
        await closure.save();

        res.json({ success: true, data: closure });
    } catch (error) {
        next(error);
    }
};

// @desc    Fechar (status → CLOSED)
// @route   POST /api/slaughter/closure/:id/close
export const closeClosure = async (req, res, next) => {
    try {
        const closure = await SlaughterClosure.findById(req.params.id);
        if (!closure) return res.status(404).json({ success: false, message: 'Fechamento não encontrado' });
        if (closure.status === 'CLOSED') return res.status(400).json({ success: false, message: 'Já está fechado' });

        // Validar obrigatórios SIF
        const linesIncomplete = closure.lines.filter(l => !l.curral || !l.municipio || !l.uf);
        if (linesIncomplete.length > 0) {
            return res.status(400).json({
                success: false,
                message: `${linesIncomplete.length} lote(s) com dados incompletos (Curral, Cidade ou UF)`,
                data: linesIncomplete.map(l => l.producerName)
            });
        }

        closure.status = 'CLOSED';

        closure.closedBy = req.user.id;
        closure.closedAt = new Date();
        await closure.save();

        // Hook PCP (simplificado por enquanto)
        // ... integração com PcpDayPlan virá no controller do PCP ou aqui ...

        res.json({ success: true, data: closure, message: 'Fechamento SIF realizado com sucesso' });
    } catch (error) {
        next(error);
    }
};

// @desc    Reabrir fechamento (admin)
// @route   POST /api/slaughter/closure/:id/reopen
export const reopenClosure = async (req, res, next) => {
    try {
        const { reason } = req.body;
        if (!reason) return res.status(400).json({ success: false, message: 'Motivo obrigatório para reabertura' });

        const closure = await SlaughterClosure.findById(req.params.id);
        if (!closure) return res.status(404).json({ success: false, message: 'Fechamento não encontrado' });
        if (closure.status !== 'CLOSED') return res.status(400).json({ success: false, message: 'Somente fechamentos CLOSED podem ser reabertos' });

        closure.status = 'DRAFT';
        closure.reopenLog.push({ by: req.user.id, at: new Date(), reason });
        await closure.save();

        res.json({ success: true, data: closure, message: 'Fechamento reaberto' });
    } catch (error) {
        next(error);
    }
};

// @desc    Exportar fechamento PDF
// @route   GET /api/slaughter/closure/:id/pdf
export const exportClosurePdf = async (req, res, next) => {
    try {
        const closure = await SlaughterClosure.findById(req.params.id);
        if (!closure) return res.status(404).json({ success: false, message: 'Fechamento não encontrado' });

        const pdfUrl = await generateClosurePDF(closure);
        res.json({ success: true, pdfUrl });
    } catch (error) {
        next(error);
    }
};

// @desc    Exportar fechamento
// @route   GET /api/slaughter/closure/:id/export
export const exportClosure = async (req, res, next) => {
    try {
        const { format } = req.query;
        const closure = await SlaughterClosure.findById(req.params.id);
        if (!closure) return res.status(404).json({ success: false, message: 'Fechamento não encontrado' });

        // Lógica de exportação virá no SifExportService
        res.status(501).json({ success: false, message: 'Exportação ainda não implementada' });
    } catch (error) {
        next(error);
    }
};
