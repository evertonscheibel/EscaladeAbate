import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';

export async function generateClosurePDF(closure) {
    return new Promise((resolve, reject) => {
        try {
            const dateStr = closure.date.toISOString().split('T')[0];
            const filename = `boletim-sif-${dateStr}.pdf`;
            const filepath = path.join('uploads', filename);

            if (!fs.existsSync('uploads')) {
                fs.mkdirSync('uploads', { recursive: true });
            }

            const doc = new PDFDocument({
                size: 'A4',
                layout: 'portrait',
                margins: { top: 40, bottom: 40, left: 40, right: 40 }
            });

            const stream = fs.createWriteStream(filepath);
            doc.pipe(stream);

            // --- HEADER ---
            // Logo
            const logoPath = path.join('frontend', 'public', 'logo.png');
            if (fs.existsSync(logoPath)) {
                doc.image(logoPath, 40, 35, { width: 100 });
            } else {
                doc.fontSize(20).font('Helvetica-Bold').text('FRIZELO', 40, 40);
            }

            doc.fontSize(22).font('Helvetica-Bold').text('BOLETIM DE ABATE', 0, 40, { align: 'center' });
            doc.moveDown(0.5);

            // Date and Location
            const today = new Date();
            const dayStr = String(today.getDate()).padStart(2, '0');
            const months = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
            const monthStr = months[today.getMonth()];
            const yearStr = today.getFullYear();

            doc.fontSize(10).font('Helvetica').text(`Terenos-MS, ${dayStr} de ${monthStr} de ${yearStr}.`, { align: 'right' });
            doc.moveDown();

            // SIF Info
            doc.fontSize(11).font('Helvetica').text(`Sr. Chefe da IF ${closure.header.sifNumber || 'XXXX'}, junto ao FRIZELO FRIGORÍFICOS LTDA.`);

            const slaughterDate = new Date(closure.date);
            const sDay = String(slaughterDate.getUTCDate()).padStart(2, '0');
            const sMonth = String(slaughterDate.getUTCMonth() + 1).padStart(2, '0');

            doc.text(`Em mãos comunicamos que pretendemos abater amanhã dia ${sDay}/${sMonth} os seguintes lotes:`);
            doc.moveDown(1.5);

            // --- TABLE ---
            let y = doc.y;
            const contentWidth = 515;
            const colWidths = {
                lote: 30,
                pecuarista: 165,
                municipio: 100,
                boi: 30,
                vaca: 30,
                total: 40,
                curral: 60,
                cor: 30,
                nf: 30
            };

            // Draw header
            doc.rect(40, y, contentWidth, 20).stroke();
            doc.fontSize(9).font('Helvetica-Bold');

            let x = 40;
            const drawCellHeader = (text, width) => {
                doc.text(text, x, y + 6, { width, align: 'center' });
                x += width;
                if (x < 40 + contentWidth) doc.moveTo(x, y).lineTo(x, y + 20).stroke();
            };

            drawCellHeader('LOTE', colWidths.lote);
            drawCellHeader('PECUARISTA', colWidths.pecuarista);
            drawCellHeader('MUNICÍPIO', colWidths.municipio);
            drawCellHeader('BOI', colWidths.boi);
            drawCellHeader('VACA', colWidths.vaca);
            drawCellHeader('TOTAL', colWidths.total);
            drawCellHeader('CURRAL', colWidths.curral);
            drawCellHeader('COR', colWidths.cor);
            drawCellHeader('NF', colWidths.nf);

            y += 20;

            // Draw Rows
            doc.font('Helvetica').fontSize(8);
            closure.lines.forEach((line) => {
                if (y > 750) {
                    doc.addPage();
                    y = 40;
                    // Draw header again if needed or just continue
                }

                doc.rect(40, y, contentWidth, 20).stroke();
                x = 40;

                const drawCell = (text, width, align = 'center') => {
                    const val = text !== undefined && text !== null ? String(text) : '//';
                    doc.text(val, x, y + 6, { width, align, ellipsis: true });
                    x += width;
                    if (x < 40 + contentWidth) doc.moveTo(x, y).lineTo(x, y + 20).stroke();
                };

                drawCell(String(line.sequence).padStart(2, '0'), colWidths.lote);
                drawCell(line.producerName, colWidths.pecuarista, 'left');
                drawCell(line.municipio, colWidths.municipio, 'left');
                drawCell(line.boi || '', colWidths.boi);
                drawCell(line.vaca || '', colWidths.vaca);
                drawCell(line.total, colWidths.total);
                drawCell(line.curral, colWidths.curral);
                drawCell(line.cor, colWidths.cor);
                drawCell(line.nf || line.gta, colWidths.nf);

                y += 20;
            });

            // Totals Row
            doc.rect(40, y, contentWidth, 20).stroke();
            doc.font('Helvetica-Bold').fontSize(9);
            x = 40;
            doc.text('TOTAL', x, y + 6, { width: colWidths.lote + colWidths.pecuarista + colWidths.municipio, align: 'right' });
            x += colWidths.lote + colWidths.pecuarista + colWidths.municipio;

            const totalBoi = closure.lines.reduce((sum, l) => sum + (l.boi || 0), 0);
            const totalVaca = closure.lines.reduce((sum, l) => sum + (l.vaca || 0), 0);
            const totalHeads = closure.lines.reduce((sum, l) => sum + (l.total || 0), 0);

            doc.text(String(totalBoi), x, y + 6, { width: colWidths.boi, align: 'center' }); x += colWidths.boi;
            doc.text(String(totalVaca), x, y + 6, { width: colWidths.vaca, align: 'center' }); x += colWidths.vaca;
            doc.text(String(totalHeads), x, y + 6, { width: colWidths.total, align: 'center' });

            doc.end();

            stream.on('finish', () => {
                resolve(`/uploads/${filename}`);
            });

            stream.on('error', reject);

        } catch (error) {
            reject(error);
        }
    });
}
