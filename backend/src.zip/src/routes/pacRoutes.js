import express from 'express';
import { protect } from '../middleware/auth.js';
import * as pacProgramController from '../controllers/pacProgramController.js';
import * as productionAreaController from '../controllers/productionAreaController.js';
import * as checklistModelController from '../controllers/checklistModelController.js';
import * as checklistExecutionController from '../controllers/checklistExecutionController.js';
import * as nonConformityController from '../controllers/nonConformityController.js';
import * as auditPackageController from '../controllers/auditPackageController.js';

const router = express.Router();

// Programs
router.route('/programs')
    .get(protect, pacProgramController.getPacPrograms)
    .post(protect, pacProgramController.createPacProgram);
router.route('/programs/:id')
    .get(protect, pacProgramController.getPacProgramById)
    .put(protect, pacProgramController.updatePacProgram)
    .delete(protect, pacProgramController.deletePacProgram);

// Areas
router.route('/areas')
    .get(protect, productionAreaController.getProductionAreas)
    .post(protect, productionAreaController.createProductionArea);
router.route('/areas/:id')
    .get(protect, productionAreaController.getProductionAreaById)
    .put(protect, productionAreaController.updateProductionArea)
    .delete(protect, productionAreaController.deleteProductionArea);

// Checklist Models
router.route('/models')
    .get(protect, checklistModelController.getChecklistModels)
    .post(protect, checklistModelController.createChecklistModel);
router.route('/models/:id')
    .get(protect, checklistModelController.getChecklistModelById)
    .put(protect, checklistModelController.updateChecklistModel)
    .delete(protect, checklistModelController.deleteChecklistModel);
router.post('/models/:id/duplicate', protect, checklistModelController.duplicateChecklistModel);

// Executions
router.route('/executions')
    .get(protect, checklistExecutionController.getChecklistExecutions)
    .post(protect, checklistExecutionController.openChecklistExecution);
router.route('/executions/:id')
    .put(protect, checklistExecutionController.updateChecklistExecution);
router.post('/executions/:id/finalize', protect, checklistExecutionController.finalizeChecklistExecution);

// Non-Conformities (CAPA)
router.route('/non-conformities')
    .get(protect, nonConformityController.getNonConformities);
router.route('/non-conformities/:id')
    .get(protect, nonConformityController.getNonConformityById)
    .put(protect, nonConformityController.updateNonConformity);

// Audit Packages
router.route('/audit-packages')
    .get(protect, auditPackageController.getAuditPackages)
    .post(protect, auditPackageController.createAuditPackage);

export default router;
