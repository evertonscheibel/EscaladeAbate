import express from 'express';
import { protect, authorize } from '../middleware/auth.js';
import { getSLASectorReport, getAssetROIReport } from '../controllers/reportController.js';

const router = express.Router();

router.use(protect);
router.use(authorize('admin', 'tecnico'));

router.get('/sla/sectors', getSLASectorReport);
router.get('/roi/assets', getAssetROIReport);

export default router;
